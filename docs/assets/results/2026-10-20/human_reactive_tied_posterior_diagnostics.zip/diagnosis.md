## Follow-up: are posterior bounds causing the poor RTD fit?

**The saved variational posteriors show no pileup against hard bounds.**
`rate_lambda`, `T_0`, and `theta_E` have positive LogNormal priors with
**no finite upper bounds**. Their posterior mean log values are all within
one prior log SD of the prior centres. `w` is far inside (0.05, 0.95).
No draw among the 20,000 saved draws lies in the outer 1% of a finite support.

![Saved human RT posteriors and actual prior supports](../assets/results/2026-10-20/human_reactive_tied_posterior_bounds.png)

*Control above ASD. Solid black: mean; shaded: central 95%; dashed:
finite support limits. The first three parameters have no upper bounds.
Delay panels include the data-derived upper limit. Original fits and
trial selection are unchanged.*

[Full-size PNG](../assets/results/2026-10-20/human_reactive_tied_posterior_bounds.png) ·
[PDF](../assets/results/2026-10-20/human_reactive_tied_posterior_bounds.pdf) ·
[Posterior support table](../assets/results/2026-10-20/human_reactive_tied_diagnosis_posterior_support_audit.csv)

| Group | Delay mean (ms) | Central 95% (ms) | Upper support (ms) | Upper limit distance from mean |
|---|---:|---:|---:|---:|
| Control | 104.48 | 102.76–105.92 | 111.189 | 8.4 posterior SD |
| ASD | 173.45 | 171.09–175.37 | 181.610 | 7.5 posterior SD |

### Timing tension and remaining optimization uncertainty

The delay limit is required by the model and earliest retained RT.
Increasing it above an observed RT makes that trial's reactive decision
time negative and density zero. A 300 ms shared delay would make **33
Control and 4 ASD trials** impossible. Three Control and one ASD trials
are below 200 ms. The fastest Control response is P53, 111.190 ms, an
incorrect left choice at +2 dB; the fastest ASD response is P52, 181.611 ms,
a left choice at −0.1 dB. These remain included valid trials; this
diagnosis does not classify them as dataset errors.

The saved model spreads RT probability more broadly than observed.
At |ΔdB| = 2, pooling both ASLs/signs with observed frequencies:

| Group | Empirical 10–90% RT interval (s) | Model 10–90% RT interval (s) | Empirical SD (s) | Model SD (s) |
|---|---|---|---:|---:|
| Control | 0.422–0.647 | 0.259–0.754 | 0.100 | 0.217 |
| ASD | 0.432–0.761 | 0.323–0.831 | 0.144 | 0.224 |

This suggests tension between early responses, the shared delay, and the
observed distribution shapes under this reactive-only baseline. It does
not establish which model extension would resolve it. Pooling also
imposes shared dynamics on potentially different participants.

There is separate **optimization uncertainty**. Control's `rate_lambda`
continues decreasing as `theta_E` increases and `T_0` decreases; its
`theta_E`/`T_0` correlation is −0.908. ASD met the stated local stability
criterion, which does not establish global convergence. An extended
convergence check is warranted before claiming the best achievable fit.
The posterior audit provides no evidence that wider hard bounds are needed.

Averaging 256 joint posterior conditional CDFs instead of using arithmetic
physical means changes the CDF by at most **0.00560 Control / 0.00642 ASD**,
versus empirical/model gaps up to 0.471 / 0.347. Mean-parameter plotting
therefore cannot explain the large mismatch in these saved fits.

[Timing comparisons](../assets/results/2026-10-20/human_reactive_tied_diagnosis_empirical_model_timing.csv) ·
[Mean-parameter versus posterior-average CDFs](../assets/results/2026-10-20/human_reactive_tied_diagnosis_mean_parameter_vs_posterior_average_cdf.csv) ·
[Diagnostic audit bundle](../assets/results/2026-10-20/human_reactive_tied_posterior_diagnostics.zip) ·
[Validation](../assets/results/2026-10-20/human_reactive_tied_diagnosis_validation.json)

Source: `ASD_Human_Data/diagnose_human_reactive_tied_posteriors.py`
([source](../assets/results/2026-10-20/diagnose_human_reactive_tied_posteriors.py)).
All original fit artifacts covered by their manifest remain byte-identical.
