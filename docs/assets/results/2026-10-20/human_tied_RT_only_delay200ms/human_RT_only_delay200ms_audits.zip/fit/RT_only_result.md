## Human RT-only TIED: 200 ms delay bound and 0.2–1.5 s trials

**Question:** can the reactive model match RT distributions when observed choices are ignored and the shared nondecision delay may reach 200 ms?

**Outcome:** Control's average condition-wise CDF gap changes from 0.292 to 0.260; ASD's changes from 0.220 to 0.238. At arithmetic physical posterior means, a substantial RTD shape mismatch remains. The delay posteriors are close to the requested 200 ms cap. 

**Selection:** `Condition == "RT"` and `0.2 <= RT_s <= 1.5`. Pool raw trials across participants and sessions, including correct and incorrect choices. **Observed response side does not enter the fit.** SD and sequential CB are excluded.

| Group | Participants | All RT trials | Prior ≤1.5 s analysis | New 0.2–1.5 s analysis |
|---|---:|---:|---:|---:|
| Control | 11 | 6,600 | 6,531 | 6,528 |
| ASD | 8 | 4,800 | 4,704 | 4,703 |

The user approved removing **four responses below 200 ms** (3 Control, 1 ASD) in addition to the 165 responses above 1.5 s already removed. Those early trials otherwise force a causal shared delay below 111/182 ms despite a wider prior. The fastest retained responses are 226.246 ms Control and 277.840 ms ASD; both groups now use **`t_E_aff ~ Uniform(0, 0.200 s)`**. There is no imputation or change to recorded RTs.

### RT-only objective and model

For each trial, retain its `Mean_dB` brightness and signed `Delta_dB` stimulus coordinates, and marginalize the unobserved response side by adding the existing left/right first-passage densities. This is a trial-level RT likelihood, conditional on the stimulus and retained RT window. It does not fit a histogram-error score.

```text
p(RT | B,D,retained) = [rho_right(RT) + rho_left(RT)] / Z(B,D)
Z(B,D) = F_right(1.5) + F_left(1.5) - F_right(0.2) - F_left(0.2)
first-passage time = RT_s - t_E_aff
```

Keep five parameters shared across both ASLs and all ten signed differences within each group: `rate_lambda`, `T_0`, `theta_E`, `w`, `t_E_aff`. The IPL/vanilla equations and other four priors are unchanged: lognormal λ/T₀/θ with natural-log means log(.2)/log(.001)/log(30) and log SDs 1.5/2/1.5; `w ~ Uniform(.05,.95)`. Plot ASL labels are 20/40 cd/m²; model levels are ≈10.892/15.089 visual dB.

**This run changes three things relative to the previous joint fit:** choices are marginalized, the four early trials are removed, and the delay prior is widened. A change in fit quality cannot be attributed to ignoring choices alone. All numerical comparisons below evaluate both parameter sets on the same new rows, with the same marginal RT likelihood and 0.2–1.5 s normalization.

### Optimization and saved posterior

One full-rank variational initialization per group transfers the previous joint-fit guide. Map the delay’s latent center and local covariance to its new 0–200 ms support, preserving the physical starting center; reset Adam, RNG (seed 0), losses and patience. CPU float64; AutoMultivariateNormal; full batches; one ELBO particle; ClippedAdam rate .0002, clip 1. Check K=40 against K=80.

At least 50,000 and at most 1,000,000 new updates. Every lower 1,000-step mean loss resets patience; require 25 subsequent windows and terminal/restored mean stability (<0.1 posterior SD over three checkpoints). Restore the selected best checkpoint. This checks recent windows and does not prove a unique/global optimum.

| Group | Selected best | Final checked | Later windows | Status |
|---|---:|---:|---:|---|
| Control | 83,000 | 108,000 | 25 | 25-window/local stability checks passed |
| ASD | 808,000 | 836,000 | 28 | 25-window/local stability checks passed |

### RTDs and CDFs

![RT-only TIED versus previous joint-fit predictions](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/human_RT_only_rtd_cdf_comparison_full_0p2_1p5s.png)

*Control above ASD; pooled RTD left and RT CDF right. Blue/orange: ASL 20/40 cd/m². Solid curves: RT-only fit at arithmetic physical posterior means; dotted curves: previous joint-fit parameters, recomputed on the same selected trials and RT window. Thin steps: data. Sum both response bounds and mix signed conditions with actual retained trial counts. No psychometric/choice score is used.*

[Full-size PNG](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/human_RT_only_rtd_cdf_comparison_full_0p2_1p5s.png) · [PDF](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/human_RT_only_rtd_cdf_comparison_full_0p2_1p5s.pdf) · [0.2–1 s display zoom](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/human_RT_only_rtd_cdf_comparison_zoom_0p2_1s.png)

| Group | Common RT metric | Previous joint-fit parameters | RT-only fit | Change |
|---|---|---:|---:|---:|
| Control | Marginal RT log likelihood (higher better) | 943.905 | 1724.23 | +780.323 |
| Control | Mean signed-condition CDF gap | 0.291916 | 0.260092 | -0.0318237 |
| Control | Largest signed-condition CDF gap | 0.339956 | 0.351508 | +0.0115529 |
| ASD | Marginal RT log likelihood (higher better) | 642.321 | 742.832 | +100.511 |
| ASD | Mean signed-condition CDF gap | 0.219902 | 0.237761 | +0.0178591 |
| ASD | Largest signed-condition CDF gap | 0.291038 | 0.330071 | +0.0390328 |

The mean CDF gap is an equal-weight average over the 20 ASL × signed-difference cells. The likelihood gives each retained trial one contribution; RTD/CDF mixtures use actual retained stimulus frequencies.


### RTDs by absolute difference

![RT-only fits by absolute difference](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/human_RT_only_rtd_by_delta_full_0p2_1p5s.png)

*Control above ASD; columns |ΔdB| = 0.1, 0.3, 0.65, 1.3, 2. Dashed steps are 20 ms empirical histograms; solid curves are the RT-only model on a 1 ms grid. Blue/orange identify ASL 20/40 cd/m². Pool ±ΔdB with actual retained counts; normalization remains 0.2–1.5 s in the display zoom. Matching axes include all peaks.*

[Full-size PNG](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/human_RT_only_rtd_by_delta_full_0p2_1p5s.png) · [PDF](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/human_RT_only_rtd_by_delta_full_0p2_1p5s.pdf) · [0.2–1 s display zoom](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/human_RT_only_rtd_by_delta_zoom_0p2_1s.png)

### Delay posterior and the requested 200 ms bound

| Group | Delay mean (ms) | SD (ms) | Central 95% (ms) | Draws above 199 ms | Draws above 195 ms |
|---|---:|---:|---|---:|---:|
| Control | 199.72961 | 0.52054 | [198.43661, 199.99074] | 95.33% | 99.85% |
| ASD | 199.59695 | 0.75814 | [197.70726, 199.98546] | 91.34% | 99.47% |

A posterior concentrated near 200 ms is constrained by the requested prior cap. It should not be described as an unconstrained estimate of the nondecision delay. The cap is marked on the corner and parameter-trace figures.

### All five posterior parameters

| Group | Parameter | Mean | SD | Central 95% |
|---|---|---:|---:|---|
| Control | rate_lambda | 0.134294 | 0.020878 | [0.097926, 0.17885] |
| Control | T_0 (ms) | 0.024938 | 0.0085595 | [0.012173, 0.045287] |
| Control | theta_E | 232.382 | 35.962 | [170.51, 311.82] |
| Control | w | 0.49941 | 0.0056649 | [0.48811, 0.51066] |
| Control | t_E_aff (ms) | 199.73 | 0.52054 | [198.44, 199.99] |
| ASD | rate_lambda | 0.218036 | 0.04486 | [0.14309, 0.31647] |
| ASD | T_0 (ms) | 0.0889369 | 0.044311 | [0.031336, 0.19978] |
| ASD | theta_E | 152.761 | 32.24 | [99.565, 226.09] |
| ASD | w | 0.504985 | 0.006078 | [0.49288, 0.51715] |
| ASD | t_E_aff (ms) | 199.597 | 0.75814 | [197.71, 199.99] |

These are **variational approximations** from 10,000 constrained draws per group. Pooled-trial posterior uncertainty does not represent participant-to-participant variability.

| Group | Parameter pair | Posterior correlation |
|---|---|---:|
| Control | T_0, rate_lambda | +0.9632 |
| Control | theta_E, T_0 | -0.9270 |
| Control | theta_E, rate_lambda | -0.9059 |
| ASD | T_0, rate_lambda | +0.9579 |
| ASD | theta_E, rate_lambda | -0.8994 |
| ASD | theta_E, T_0 | -0.8775 |

[Control corner](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/control/parameter_corner.png) · [ASD corner](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/asd/parameter_corner.png) · [Control loss/parameter traces](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/control/convergence.png) · [ASD loss/parameter traces](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/asd/convergence.png)

The strong λ/T₀/θ correlations and gradual movement in their traces remain. Passing the recent-window checks does not establish unique parameter estimates or global optimality.

### Sources and independent checks

Fit root: `ASD_Human_Data/reactive_tied_rt_only_svi_0p2_1p5s_delay200ms/`. Previous joint fit: `ASD_Human_Data/reactive_tied_rt_svi_rt_le_1p5s/`.

[Selected/excluded counts](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/selection_counts.csv) · [Excluded trial identities](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/excluded_trials.csv) · [Participant counts](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/participant_selection_counts.csv) · [Condition counts](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/condition_selection_counts.csv) · [Common RT likelihood/CDF metrics](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/common_RT_fit_quality.csv) · [Delay-boundary diagnostics](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/delay_boundary_diagnostics.csv) · [Posterior summaries](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/parameter_summary.csv) · [Independent validation](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/independent_validation.json) · [Full posterior/source/audit ZIP](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/human_RT_only_delay200ms_audits.zip)

- `ASD_Human_Data/human_reactive_tied_rt_only_utils.py` ([source](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/source/human_reactive_tied_rt_only_utils.py)).
- `ASD_Human_Data/fit_human_reactive_tied_rt_only_svi.py` ([source](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/source/fit_human_reactive_tied_rt_only_svi.py)).
- `ASD_Human_Data/plot_human_reactive_tied_rt_only_svi.py` ([source](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/source/plot_human_reactive_tied_rt_only_svi.py)).
- `ASD_Human_Data/verify_human_reactive_tied_rt_only_svi.py` ([source](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/source/verify_human_reactive_tied_rt_only_svi.py)).
- `ASD_Human_Data/publish_human_reactive_tied_rt_only_svi.py` ([source](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/source/publish_human_reactive_tied_rt_only_svi.py)).
- `ASD_Human_Data/human_tied_independent_fpt.py` ([source](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/source/human_tied_independent_fpt.py)).
- `ASD_Human_Data/human_reactive_tied_svi_utils.py` ([source](../assets/results/2026-10-20/human_tied_RT_only_delay200ms/source/human_reactive_tied_svi_utils.py)).

Independent checks matched all 11,231 retained and 169 excluded source identities; flipping/adding response labels left the RT likelihood and gradients unchanged. Checks verified the five free parameters and 200 ms support, posterior summaries/covariances, warm-start coordinate mapping, each patience reset, finite gradients, K=40/80 convergence, SciPy density/CDF agreement and unit conditional mass. Reconstructed 80 condition-wise CDF checks, 1560 histogram bins and 160 mixture weights. All 417 prior fit/asset files are byte-identical. PNGs were visually inspected and PDFs passed text-bound checks.
