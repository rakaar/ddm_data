## Human RT-only TIED: 0–1.8 s trials and a 0–300 ms delay prior

**Selection:** `Condition == "RT"` and `0 <= RT_s <= 1.8`. Pool raw trials across participants and sessions within each group; keep correct and incorrect trials. Observed response side is ignored in fitting. SD and sequential CB are excluded.

| Group | Participants | All RT trials | Retained 0–1.8 s | Excluded >1.8 s |
|---|---:|---:|---:|---:|
| Control | 11 | 6,600 | 6,574 | 26 |
| ASD | 8 | 4,800 | 4,770 | 30 |

**All four RTs below 200 ms are retained.** The user rounded the pooled 99.5th percentile (1.792625 s) to **1.8 s**. This selection keeps 11,344 trials and excludes 56, rather than the 57 excluded by the exact percentile. Relative to the preceding 250-ms-prior analysis, the retained window changes from 0.25–1.5 to 0–1.8 s, adding eight responses below 250 ms and 109 responses between 1.5 and 1.8 s. Recorded RTs are not shifted.

### Requested prior and causal support

The fitted model uses **`t_E_aff ~ Uniform(0, 0.300 s)`**. The other four priors remain LogNormal(log(.2), 1.5) for `rate_lambda`, LogNormal(log(.001), 2) for `T_0` (seconds), LogNormal(log(30), 1.5) for `theta_E`, and Uniform(.05,.95) for `w`. LogNormal arguments use natural logarithms; the three positive parameters have no finite upper hard bound.

The likelihood is zero for a delay at or above any retained RT. The earliest retained RT is **111.1898 ms Control** and **181.6110 ms ASD**. These are data-imposed posterior support limits, distinct from the requested 300 ms prior ceiling and the RT data cutoff.

For numerical SVI, a separate guide-only prototype gives AutoMultivariateNormal a delay transform confined to the positive-likelihood interval. The actual SVI model still evaluates the Uniform(0,.300) prior with its original density. The prototype’s prior is used only to construct the guide transform. Independent checks verify the model/prototype log-density difference is exactly log(causal_upper/.300) at valid parameters, and that noncausal delays have zero likelihood despite lying inside the requested prior. No extra RTs are discarded to enlarge delay support.

### Five shared parameters and RT-only likelihood

Each group has five parameters shared across both ASLs and all ten signed differences: `rate_lambda`, `T_0`, `theta_E`, `w`, `t_E_aff`. Use the unchanged IPL/vanilla density and CDF primitives with `B = Mean_dB` and `D = Delta_dB` (right minus left). ASL plot labels are 20/40 cd/m²; model brightness coordinates are ≈10.892/15.089 visual dB.

```text
gamma = theta_E * tanh(rate_lambda * D / 17.37)
omega = 10**(rate_lambda * B / 20) * cosh(rate_lambda * D / 17.37) / (T_0 * theta_E**2)
Z_E = (w - 0.5) * 2 * theta_E
first-passage time = RT_s - t_E_aff
p(RT | B,D,retained) = [rho_right(RT) + rho_left(RT)] / Z(B,D)
Z(B,D) = F_right(1.8) + F_left(1.8) - F_right(0) - F_left(0)
```

This fits the trial-level RT likelihood conditional on stimulus and retention, marginalizing response side. No histogram-error or psychometric objective is fitted.

### Data and mean-parameter fit curves

![Human 0–1.8 s RT-only data and fitted curves](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/human_RT_only_rtd_cdf_comparison_full_0_1p8s.png)

*Control above ASD; pooled RTD left and CDF right. Blue/orange denote ASL 20/40 cd/m². Steps show data; solid curves evaluate the model at arithmetic posterior means of the five physical parameters. Sum both response bounds and mix signed conditions using actual retained trial counts. Both data and predictions are conditional on 0–1.8 s. RTD bins are 20 ms; the model grid is 1 ms. Each panel retains its group’s recorded early RTs.*

[Full-size PNG](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/human_RT_only_rtd_cdf_comparison_full_0_1p8s.png) · [PDF](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/human_RT_only_rtd_cdf_comparison_full_0_1p8s.pdf) · [0–1.5 s display zoom](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/human_RT_only_rtd_cdf_comparison_zoom_0_1p5s.png)

**Visual assessment:** At arithmetic physical posterior means, both model RTDs remain substantially broader than the data, with peaks that are too low and tails too heavy. The delay means are 102.04 ms Control and 170.65 ms ASD; neither posterior is near the requested 300-ms ceiling. The retained earliest RTs impose separate causal limits. Both groups pass the specified post-minimum and terminal-stability checks; movement at the selected minimum remains a diagnostic.

| Group | RT log likelihood at physical means | Mean condition CDF gap | Largest condition CDF gap |
|---|---:|---:|---:|
| Control | 358.431 | 0.327775 | 0.423724 |
| ASD | 185.053 | 0.255719 | 0.327416 |

The likelihood weights individual trials equally. The mean CDF gap is an equal-weight average over the 20 ASL × signed-difference cells. Pooled curves use actual retained stimulus frequencies. These scores use the current selection and are not directly comparable with training scores from the earlier truncated datasets.

![RT-only fits by absolute difference](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/human_RT_only_rtd_by_delta_full_0_1p8s.png)

*Control above ASD; columns |ΔdB| = 0.1, 0.3, 0.65, 1.3, 2. Blue/orange identify ASL 20/40 cd/m². Dashed steps show empirical RTDs; solid lines show the model at the physical posterior means. Pool ±ΔdB with their actual retained frequencies. Full and zoomed views retain 0–1.8 s normalization, with common axes including all peaks.*

[Full-size PNG](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/human_RT_only_rtd_by_delta_full_0_1p8s.png) · [PDF](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/human_RT_only_rtd_by_delta_full_0_1p8s.pdf) · [0–1.5 s display zoom](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/human_RT_only_rtd_by_delta_zoom_0_1p5s.png)

### Posterior parameters

| Group | Parameter | Mean | SD | Central 95% interval |
|---|---|---:|---:|---|
| Control | rate_lambda | 0.133155 | 0.019732 | [0.098577, 0.17509] |
| Control | T_0 (ms) | 0.0282623 | 0.0091799 | [0.01435, 0.049918] |
| Control | theta_E | 256.757 | 37.641 | [191.6, 339.7] |
| Control | w | 0.504394 | 0.0051354 | [0.49414, 0.51463] |
| Control | t_E_aff (ms) | 102.035 | 1.2059 | [99.427, 104.16] |
| ASD | rate_lambda | 0.231903 | 0.032616 | [0.1744, 0.30091] |
| ASD | T_0 (ms) | 0.107497 | 0.03527 | [0.05405, 0.19116] |
| ASD | theta_E | 136.045 | 19.157 | [102.74, 178.16] |
| ASD | w | 0.509886 | 0.0064771 | [0.49697, 0.52282] |
| ASD | t_E_aff (ms) | 170.65 | 1.6992 | [166.91, 173.58] |

These are **variational approximations** from 10,000 constrained draws per group. Pooled-trial posterior uncertainty does not represent participant-to-participant variability. The plots use arithmetic physical means rather than posterior-averaged predictions.

| Group | Causal delay limit (ms) | Draws within 1 ms of causal limit | Draws >299 ms |
|---|---:|---:|---:|
| Control | 111.18980 | 0.00% | 0.00% |
| ASD | 181.61100 | 0.00% | 0.00% |

| Group | Parameter pair | Posterior correlation |
|---|---|---:|
| Control | T_0, rate_lambda | +0.9641 |
| Control | theta_E, T_0 | -0.9309 |
| Control | theta_E, rate_lambda | -0.9039 |
| ASD | T_0, rate_lambda | +0.9512 |
| ASD | theta_E, T_0 | -0.9216 |
| ASD | theta_E, rate_lambda | -0.8665 |

### Initialization and stopping checks

One warm start per group uses the confirmed earlier joint fit `ASD_Human_Data/reactive_tied_rt_svi_rt_le_1p5s/`, which retained the same earliest responses. Later 200/250-ms RT-only fits have incompatible delay starting values. Map the delay’s latent center and local covariance to the causal guide interval, preserving its physical starting center. Reset Adam, RNG (seed 0), losses and patience for the new objective. CPU float64; full-batch AutoMultivariateNormal; one ELBO particle; ClippedAdam learning rate .0002, clip 1; minimum 50k and maximum 1M new updates.

**Stopping correction:** the earlier scripts additionally required backward-looking stability at the selected minimum itself. That extra gate can prevent stopping even after many post-minimum windows. This run follows the original requested rule: every lower 1,000-step mean loss resets patience; require at least 25 subsequent windows and terminal mean stability below 0.1 posterior SD over three checkpoints, then restore the minimum. The selected checkpoint’s own movement is recorded as a diagnostic. The Control optimizer/RNG/checkpoint trajectory was preserved when applying this correction; no additional statistical initialization was introduced. Earlier runs and their reported stopping rules are preserved.

**Checkpoint repair:** the interrupted original Control worker continued writing after the resumed fit stopped. That leftover worker was terminated, and its extra iterations were archived. The original saved initialization and RNG trajectory were replayed through the accepted stop. Every loss and checkpoint mean was checked, all 10,000 posterior draws were reproduced, and the best/latest checkpoints were restored. The accepted posterior and guide files are byte-identical to their pre-repair values. The repair record and archived traces are included in the audit bundle.

| Group | Selected best | Final checked | Later windows | Terminal stable | Selected checkpoint stable (diagnostic) | Status |
|---|---:|---:|---:|---|---|---|
| Control | 40,000 | 81,000 | 41 | True | False | Required checks passed |
| ASD | 40,000 | 65,000 | 25 | True | False | Required checks passed |

Passing these observed-window checks does not establish a global optimum or unique parameter estimates. Strong parameter correlations are shown above.

[Control corner](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/control/parameter_corner.png) · [ASD corner](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/asd/parameter_corner.png) · [Control convergence](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/control/convergence.png) · [ASD convergence](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/asd/convergence.png)

### Sources and audits

Fit root: `ASD_Human_Data/reactive_tied_rt_only_svi_0_1p8s_delay300ms/`.

[Configuration](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/run_config.json) · [Protocol](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/analysis_protocol.json) · [Prior/guide preflight](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/prior_guide_preflight.json) · [Stopping correction](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/stopping_rule_correction.json) · [Checkpoint repair](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/checkpoint_repair.json) · [Selection counts](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/selection_counts.csv) · [Excluded rows](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/excluded_trials.csv) · [Participant counts](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/participant_selection_counts.csv) · [Condition counts](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/condition_selection_counts.csv) · [RT fit metrics](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/RT_fit_quality.csv) · [Posterior summaries](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/parameter_summary.csv) · [Delay support diagnostics](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/delay_boundary_diagnostics.csv) · [Independent verification](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/independent_validation.json) · [Full posterior/source/audit ZIP](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/human_RT_only_delay300ms_audits.zip)

- `ASD_Human_Data/human_reactive_tied_rt_only_utils.py` ([source](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/source/human_reactive_tied_rt_only_utils.py)).
- `ASD_Human_Data/human_reactive_tied_rt_only_support_utils.py` ([source](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/source/human_reactive_tied_rt_only_support_utils.py)).
- `ASD_Human_Data/fit_human_reactive_tied_rt_only_delay300_svi.py` ([source](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/source/fit_human_reactive_tied_rt_only_delay300_svi.py)).
- `ASD_Human_Data/plot_human_reactive_tied_rt_only_delay300_svi.py` ([source](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/source/plot_human_reactive_tied_rt_only_delay300_svi.py)).
- `ASD_Human_Data/verify_human_reactive_tied_rt_only_delay300_svi.py` ([source](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/source/verify_human_reactive_tied_rt_only_delay300_svi.py)).
- `ASD_Human_Data/publish_human_reactive_tied_rt_only_delay300_svi.py` ([source](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/source/publish_human_reactive_tied_rt_only_delay300_svi.py)).
- `ASD_Human_Data/human_tied_independent_fpt.py` ([source](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/source/human_tied_independent_fpt.py)).
- `ASD_Human_Data/human_reactive_tied_svi_utils.py` ([source](../assets/results/2026-10-20/human_tied_RT_only_delay300ms/source/human_reactive_tied_svi_utils.py)).

Independent checks verified all 11,344 retained and 56 excluded source identities, all four sub-200-ms responses, the actual 300-ms prior and causal guide supports, prior normalization, five free parameters, response-label invariance, finite gradients, K=40/80 series convergence, independent SciPy density/CDF agreement, conditional unit mass, posterior summaries, warm-start mapping, and every patience reset. Reconstructed 40 condition CDF comparisons, 2160 histogram bins and 80 mixture weights. Earlier fit/figure files were hash checked, prior documentation preserved, PNGs visually inspected, and PDF text bounds checked.
