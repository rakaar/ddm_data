## Human RT: refit after removing responses above 1.5 s

**Question:** do the long responses explain the poor reactive-only TIED fits?

**Outcome:** removing the long tail does **not resolve the RTD shape mismatch** in this five-parameter pooled fit. Both groups improve their common-window joint likelihood and largest signed-condition CDF gap, but their average condition-wise CDF gaps increase. The model RTDs remain much broader and less peaked than the data.

**Selection:** `Condition == "RT"` and `RT_s <= 1.5`. This is a new trial filter, with likelihood and predictions conditional on **0–1.5 s**. Earlier figures used all 11,400 recorded RT trials and 0–3 s normalization; their 1.5 s view was only a display zoom. Correct and incorrect choices remain included, with raw trials pooled across participants and sessions. SD and sequential CB are excluded.

| Group | Participants | Original RT trials | Retained ≤1.5 s | Removed >1.5 s |
|---|---:|---:|---:|---:|
| Control | 11 | 6,600 | 6,531 | 69 |
| ASD | 8 | 4,800 | 4,704 | 96 |

Only **165/11,400 trials (1.45%)** are removed. All 19 participants, both ASLs and all ten signed differences remain. Cell counts are now unequal, so model mixtures use actual retained trial frequencies. The fastest trials are retained: delay support remains `0 < t_E_aff < 0.111188799848944 s` for Control and `0 < t_E_aff < 0.181610000094563 s` for ASD.

### Model and refitting

The same five parameters (`rate_lambda`, `T_0`, `theta_E`, `w`, `t_E_aff`) are shared across both ASLs and all signed differences within each group. The IPL/vanilla equations use `B = Mean_dB`, `D = Delta_dB`, `Choice = +1/-1` for right/left, and first-passage time `RT_s - t_E_aff`. Divide each choice density by the **either-bound mass** in 0–1.5 s. ASL 20/40 cd/m² are plot labels, with actual model levels ≈10.892/15.089 visual dB.

Priors are unchanged: lognormal λ/T₀/θ with natural-log means log(.2)/log(.001)/log(30) and log SDs 1.5/2/1.5; uniform w in (.05,.95) and delay below the group minimum RT minus 1 μs. One warm start per group uses the previous confirmed **full-rank guide**, then resets Adam, RNG (seed 0), loss history and patience because the target likelihood changed. The actual initial guide covariance is the saved covariance. This is a new fit, rather than an optimizer-state continuation.

CPU float64; NumPyro AutoMultivariateNormal; full batches, one ELBO particle; ClippedAdam learning rate .0002 and clip 1; K=40 checked against K=80. Check 1,000-step means, minimum 50,000 and cap 1,000,000 new updates. Every lower mean resets patience; require 25 later windows and terminal/restored mean stability (<0.1 posterior SD over three checkpoints), then restore the best checkpoint. This is observed-window confirmation, not proof of a global optimum.

| Group | Selected best step | Final checked step | Later windows | Status |
|---|---:|---:|---:|---|
| Control | 276,000 | 301,000 | 25 | confirmed; means stable |
| ASD | 40,000 | 65,000 | 25 | confirmed; means stable |

### Previous versus refitted model on the same selected trials

![Human TIED refit after the 1.5 s cutoff](../assets/results/2026-10-20/human_tied_rt_le_1p5s/human_tied_rt_cutoff_comparison.png)

*Control above ASD; psychometric left and pooled RTD right. Solid curves: new fit. Dotted curves: previous confirmed full-RT fit, recomputed and reconditioned on 0–1.5 s. Blue/orange identify ASL 20/40 cd/m²; points/steps show the same retained data. Both predictions use arithmetic means of physical posterior parameters and actual retained condition frequencies.*

[Full-size PNG](../assets/results/2026-10-20/human_tied_rt_le_1p5s/human_tied_rt_cutoff_comparison.png) · [PDF](../assets/results/2026-10-20/human_tied_rt_le_1p5s/human_tied_rt_cutoff_comparison.pdf)

**Common-window comparison:** both models are evaluated on exactly the same selected rows with 0–1.5 s normalization. The original training losses on all trials cannot be compared directly with the new training losses.

| Group | Metric | Previous parameters, reconditioned | Refit | Change |
|---|---|---:|---:|---:|
| Control | Joint log likelihood at means (higher better) | -1656.37 | -1530.02 | +126.35 |
| Control | Psychometric RMSE | 0.0322991 | 0.0288927 | -0.0034065 |
| Control | Mean signed-condition RT CDF gap | 0.250921 | 0.291909 | +0.040988 |
| Control | Largest signed-condition RT CDF gap | 0.437899 | 0.34112 | -0.096779 |
| ASD | Joint log likelihood at means (higher better) | -1283.57 | -1213.56 | +70.006 |
| ASD | Psychometric RMSE | 0.0526354 | 0.0509981 | -0.0016372 |
| ASD | Mean signed-condition RT CDF gap | 0.182738 | 0.219948 | +0.03721 |
| ASD | Largest signed-condition RT CDF gap | 0.305221 | 0.291038 | -0.014182 |

### RTDs for each absolute difference

![Refitted RTDs by absolute difference](../assets/results/2026-10-20/human_tied_rt_le_1p5s/human_reactive_tied_rtd_by_delta_full_0_1p5s.png)

*Control above ASD; columns |ΔdB| = 0.1, 0.3, 0.65, 1.3, 2. Data: 20 ms histogram steps; model: 1 ms curves at arithmetic posterior means. Pool ±ΔdB with observed retained counts and sum both choices. Matching axes include all histogram and model peaks; histograms and model densities have unit area over the fitted 0–1.5 s window.*

[Full-size PNG](../assets/results/2026-10-20/human_tied_rt_le_1p5s/human_reactive_tied_rtd_by_delta_full_0_1p5s.png) · [PDF](../assets/results/2026-10-20/human_tied_rt_le_1p5s/human_reactive_tied_rtd_by_delta_full_0_1p5s.pdf) · [Refit psychometric/RTD PNG](../assets/results/2026-10-20/human_tied_rt_le_1p5s/human_reactive_tied_psychometric_rtd_full_0_1p5s.png) · [0–1 s display zoom](../assets/results/2026-10-20/human_tied_rt_le_1p5s/human_reactive_tied_psychometric_rtd_zoom_0_1s.png)

### Posterior parameters

| Group | Parameter | Mean | SD | Central 95% interval |
|---|---|---:|---:|---|
| Control | rate_lambda | 0.128653 | 0.01752 | [0.097651, 0.16562] |
| Control | T_0 (ms) | 0.0313894 | 0.0095638 | [0.016629, 0.053731] |
| Control | theta_E | 240.611 | 33.504 | [182.12, 314.11] |
| Control | w | 0.488758 | 0.003936 | [0.48093, 0.49659] |
| Control | t_E_aff (ms) | 101.825 | 1.2351 | [99.176, 104.04] |
| ASD | rate_lambda | 0.221532 | 0.028324 | [0.17107, 0.281] |
| ASD | T_0 (ms) | 0.119425 | 0.035719 | [0.063866, 0.20332] |
| ASD | theta_E | 126.682 | 16.391 | [98.085, 162.33] |
| ASD | w | 0.511031 | 0.0046747 | [0.50167, 0.52034] |
| ASD | t_E_aff (ms) | 169.672 | 1.8266 | [165.67, 172.88] |

These are **variational approximations**, from 10,000 constrained draws per group. Pooled-trial posterior uncertainty does not measure participant-to-participant variability.

| Group | Parameter pair | Posterior correlation |
|---|---|---:|
| Control | T_0, rate_lambda | +0.9633 |
| Control | theta_E, T_0 | -0.9405 |
| Control | theta_E, rate_lambda | -0.9181 |
| ASD | T_0, rate_lambda | +0.9493 |
| ASD | theta_E, T_0 | -0.9361 |
| ASD | theta_E, rate_lambda | -0.8852 |

[Control corner](../assets/results/2026-10-20/human_tied_rt_le_1p5s/control/parameter_corner.png) · [ASD corner](../assets/results/2026-10-20/human_tied_rt_le_1p5s/asd/parameter_corner.png) · [Control loss/parameter traces](../assets/results/2026-10-20/human_tied_rt_le_1p5s/control/convergence.png) · [ASD loss/parameter traces](../assets/results/2026-10-20/human_tied_rt_le_1p5s/asd/convergence.png)

λ, T₀ and θ remain strongly correlated; the traces show slow movement along this parameter tradeoff. The stopping checks assess recent windows and do not establish a unique/global minimum. The fastest retained responses still constrain the shared delay.

### Sources, selected rows and verification

Previous fit root: `ASD_Human_Data/reactive_tied_rt_svi_confirm25/`. New fit root: `ASD_Human_Data/reactive_tied_rt_svi_rt_le_1p5s/`.

[Selection counts](../assets/results/2026-10-20/human_tied_rt_le_1p5s/selection_counts.csv) · [Condition counts](../assets/results/2026-10-20/human_tied_rt_le_1p5s/condition_selection_counts.csv) · [Participant counts](../assets/results/2026-10-20/human_tied_rt_le_1p5s/participant_selection_counts.csv) · [Excluded trial identities](../assets/results/2026-10-20/human_tied_rt_le_1p5s/excluded_long_trials.csv) · [Common-window fit quality](../assets/results/2026-10-20/human_tied_rt_le_1p5s/common_window_fit_quality.csv) · [Parameter summaries](../assets/results/2026-10-20/human_tied_rt_le_1p5s/parameter_summary.csv) · [Independent validation](../assets/results/2026-10-20/human_tied_rt_le_1p5s/independent_validation.json) · [Full posterior/source/audit ZIP](../assets/results/2026-10-20/human_tied_rt_le_1p5s/human_tied_rt_le_1p5s_audits.zip)

- `ASD_Human_Data/human_reactive_tied_window_utils.py` ([source](../assets/results/2026-10-20/human_tied_rt_le_1p5s/source/human_reactive_tied_window_utils.py)).
- `ASD_Human_Data/fit_human_reactive_tied_window_svi.py` ([source](../assets/results/2026-10-20/human_tied_rt_le_1p5s/source/fit_human_reactive_tied_window_svi.py)).
- `ASD_Human_Data/plot_human_reactive_tied_window_svi.py` ([source](../assets/results/2026-10-20/human_tied_rt_le_1p5s/source/plot_human_reactive_tied_window_svi.py)).
- `ASD_Human_Data/compare_human_reactive_tied_window.py` ([source](../assets/results/2026-10-20/human_tied_rt_le_1p5s/source/compare_human_reactive_tied_window.py)).
- `ASD_Human_Data/verify_human_reactive_tied_window_svi.py` ([source](../assets/results/2026-10-20/human_tied_rt_le_1p5s/source/verify_human_reactive_tied_window_svi.py)).
- `ASD_Human_Data/publish_human_reactive_tied_window.py` ([source](../assets/results/2026-10-20/human_tied_rt_le_1p5s/source/publish_human_reactive_tied_window.py)).
- `ASD_Human_Data/human_reactive_tied_svi_utils.py` ([source](../assets/results/2026-10-20/human_tied_rt_le_1p5s/source/human_reactive_tied_svi_utils.py)).

Independent verification matched all 11,235 retained and 165 excluded source identities, verified both groups' posterior summaries/covariances and strict patience resets, checked finite gradients, K=40/80 series, SciPy density/CDF agreement and unit conditional mass. It reconstructed 40 probabilities, 1800 histogram bins and both parameter sets' common-window comparisons. All 265 previous fit/asset files are byte-identical. Figures were visually inspected and PDFs passed text-bound checks.
