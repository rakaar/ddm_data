## Human RT: continuation with strict minimum confirmation

**Outcome:** the corrected continuation found lower variational losses and substantially different parameters in both groups. Improvements in the data fit are modest and mixed: the largest RT CDF gaps decrease (Control 0.471 → 0.437; ASD 0.347 → 0.310), but average signed-condition CDF gaps increase slightly. The major RTD shape mismatch remains.

This continues the original Control and ASD fits from their exact saved optimizer, guide, and RNG states. **Data, priors, likelihood and five shared parameters per group are unchanged.** Condition = RT only: 6,600 Control trials from 11 participants and 4,800 ASD trials from 8; all retained choices and RTs, both ASLs and all signed differences, with no additional filter.

Every lower **1,000-step mean negative ELBO** resets patience. Require **25 subsequent windows** without a new best, plus terminal and restored-best mean stability (<0.1 posterior SD over three checkpoints). Restore the lowest finite window checkpoint. The cap is 1,000,000 total updates per group; a capped unfinished confirmation remains flagged. This confirms the specified observed-window criterion, not a global optimum.

| Group | Original endpoint | Continued best | Final checked | Post-best windows | Status |
|---|---:|---:|---:|---:|---|
| Control | 150,000 | 514,000 | 539,000 | 25 | confirmed; means stable |
| ASD | 127,000 | 514,000 | 539,000 | 25 | confirmed; means stable |

### Original versus continued psychometrics and RTDs

![Original and continued human reactive-only TIED fits](../assets/results/2026-10-20/human_tied_confirm25/comparison/human_tied_original_vs_continued_zoom_0_1p5s.png)

*Control above ASD. Solid model curves: continued fit; dotted model curves: original fit. Blue/orange identify ASL 20/40 cd/m²; points and light steps show the same empirical data. Both versions use arithmetic physical posterior means and the identical joint RT/choice likelihood conditional on 0–3 s. The 0–1.5 s view is a display zoom. Model brightness is `Mean_dB`; nominal `ASL_cd` remains the legend label.*

[Full-size comparison PNG](../assets/results/2026-10-20/human_tied_confirm25/comparison/human_tied_original_vs_continued_zoom_0_1p5s.png) · [Comparison PDF](../assets/results/2026-10-20/human_tied_confirm25/comparison/human_tied_original_vs_continued_zoom_0_1p5s.pdf) · [Full 0–3 s PNG](../assets/results/2026-10-20/human_tied_confirm25/comparison/human_tied_original_vs_continued_full_0_3s.png) · [Full 0–3 s PDF](../assets/results/2026-10-20/human_tied_confirm25/comparison/human_tied_original_vs_continued_full_0_3s.pdf)

### Did fit quality improve?

| Group | Metric | Original | Continued | Change |
|---|---|---:|---:|---:|
| Control | Joint log likelihood at means (higher better) | -2696.3 | -2687.2 | +9.0855 |
| Control | Psychometric RMSE (lower better) | 0.031982 | 0.030535 | -0.0014464 |
| Control | Largest choice-probability error | 0.064276 | 0.063372 | -0.00090355 |
| Control | Mean signed-condition RT CDF gap | 0.31725 | 0.32029 | +0.0030336 |
| Control | Largest signed-condition RT CDF gap | 0.47051 | 0.43666 | -0.033851 |
| ASD | Joint log likelihood at means (higher better) | -2145.4 | -2144.9 | +0.57576 |
| ASD | Psychometric RMSE (lower better) | 0.053716 | 0.053272 | -0.00044415 |
| ASD | Largest choice-probability error | 0.12022 | 0.12133 | +0.0011112 |
| ASD | Mean signed-condition RT CDF gap | 0.24665 | 0.25121 | +0.0045557 |
| ASD | Largest signed-condition RT CDF gap | 0.34687 | 0.31028 | -0.036586 |

The likelihood and curve discrepancies assess the same trial population. A lower variational loss need not improve every descriptive curve-error metric.

A separate evaluation uses **256 common random draws** per original/continued guide to compare expected negative ELBO without further training:

| Group | Original negative ELBO | Continued negative ELBO | Paired change ± MC SEM |
|---|---:|---:|---:|
| ASD | 2169.894 | 2161.245 | -8.649 ± 0.153 |
| Control | 2721.396 | 2707.185 | -14.211 ± 0.129 |

### Parameter changes

| Group | Parameter | Original mean | Continued mean | Continued central 95% |
|---|---|---:|---:|---|
| Control | rate_lambda | 0.24815 | 0.14628 | [0.11749, 0.1793] |
| Control | T_0 (ms) | 0.15505 | 0.046372 | [0.028148, 0.071687] |
| Control | theta_E | 98.686 | 170.54 | [136.72, 211.74] |
| Control | w | 0.48743 | 0.48709 | [0.47819, 0.496] |
| Control | t_E_aff (ms) | 104.48 | 104.57 | [102.86, 105.99] |
| ASD | rate_lambda | 0.31991 | 0.21241 | [0.16604, 0.26661] |
| ASD | T_0 (ms) | 0.30872 | 0.11771 | [0.06532, 0.19492] |
| ASD | theta_E | 71.211 | 109.23 | [85.167, 139.13] |
| ASD | w | 0.50721 | 0.50726 | [0.49655, 0.51787] |
| ASD | t_E_aff (ms) | 173.45 | 173.52 | [171.18, 175.44] |

*Intervals are variational approximations from 10,000 constrained draws per group. Pooled-trial uncertainty does not measure participant-to-participant variability. The continuation adds no new statistical initialization.*

### RTDs at each absolute difference

![Continued human TIED RTDs by absolute difference](../assets/results/2026-10-20/human_tied_confirm25/human_reactive_tied_rtd_by_delta_zoom_0_1p5s.png)

*Control above ASD; columns |ΔdB| = 0.1, 0.3, 0.65, 1.3, 2. Pool the two signs with observed trial frequencies, sum both choices, and retain 0–3 s normalization. Empirical 20 ms steps and model 1 ms curves use the same ASL colors and matching axes.*

[Full-size PNG](../assets/results/2026-10-20/human_tied_confirm25/human_reactive_tied_rtd_by_delta_zoom_0_1p5s.png) · [PDF](../assets/results/2026-10-20/human_tied_confirm25/human_reactive_tied_rtd_by_delta_zoom_0_1p5s.pdf) · [Full 0–3 s PNG](../assets/results/2026-10-20/human_tied_confirm25/human_reactive_tied_rtd_by_delta_full_0_3s.png) · [Full 0–3 s PDF](../assets/results/2026-10-20/human_tied_confirm25/human_reactive_tied_rtd_by_delta_full_0_3s.pdf)

### Minimum-confirmation evidence

![Strict post-best loss confirmation](../assets/results/2026-10-20/human_tied_confirm25/comparison/human_tied_continuation_confirmation.png)

*Gray dashed lines mark the original endpoints; black dotted lines mark selected minima and the required 25-window counter. The saved convergence CSVs retain the entire original history and explicitly replay strict patience for every window.*

[Confirmation PDF](../assets/results/2026-10-20/human_tied_confirm25/comparison/human_tied_continuation_confirmation.pdf) · [Control corner](../assets/results/2026-10-20/human_tied_confirm25/control/parameter_corner.png) · [ASD corner](../assets/results/2026-10-20/human_tied_confirm25/asd/parameter_corner.png) · [Control parameter traces](../assets/results/2026-10-20/human_tied_confirm25/control/convergence.png) · [ASD parameter traces](../assets/results/2026-10-20/human_tied_confirm25/asd/convergence.png)

### Reproduction and audits

Source fit: `ASD_Human_Data/reactive_tied_rt_svi/`; continued fit: `ASD_Human_Data/reactive_tied_rt_svi_confirm25/`.

[Fit-quality changes](../assets/results/2026-10-20/human_tied_confirm25/comparison/fit_quality_changes.csv) · [Parameter changes](../assets/results/2026-10-20/human_tied_confirm25/comparison/parameter_changes.csv) · [Numerical/source-row verification](../assets/results/2026-10-20/human_tied_confirm25/independent_validation.json) · [Continuation verification](../assets/results/2026-10-20/human_tied_confirm25/continuation_validation.json) · [Full posterior/calculation/source audit ZIP](../assets/results/2026-10-20/human_tied_confirm25/human_tied_confirm25_audits.zip)

- `ASD_Human_Data/continue_human_reactive_tied_svi.py` ([source](../assets/results/2026-10-20/human_tied_confirm25/source/continue_human_reactive_tied_svi.py)).
- `ASD_Human_Data/compare_human_reactive_tied_continuation.py` ([source](../assets/results/2026-10-20/human_tied_confirm25/source/compare_human_reactive_tied_continuation.py)).
- `ASD_Human_Data/fit_human_reactive_tied_svi.py` ([source](../assets/results/2026-10-20/human_tied_confirm25/source/fit_human_reactive_tied_svi.py)).
- `ASD_Human_Data/verify_human_reactive_tied_continuation.py` ([source](../assets/results/2026-10-20/human_tied_confirm25/source/verify_human_reactive_tied_continuation.py)).
- `ASD_Human_Data/plot_human_reactive_tied_svi.py` ([source](../assets/results/2026-10-20/human_tied_confirm25/source/plot_human_reactive_tied_svi.py)).
- `ASD_Human_Data/verify_human_reactive_tied_svi.py` ([source](../assets/results/2026-10-20/human_tied_confirm25/source/verify_human_reactive_tied_svi.py)).
- `ASD_Human_Data/human_reactive_tied_svi_utils.py` ([source](../assets/results/2026-10-20/human_tied_confirm25/source/human_reactive_tied_svi_utils.py)).
- `ASD_Human_Data/publish_human_reactive_tied_continuation.py` ([source](../assets/results/2026-10-20/human_tied_confirm25/source/publish_human_reactive_tied_continuation.py)).

Verification matched all 11,400 source trial identities, retained the exact original raw-loss prefixes, replayed every patience reset, checked posterior summaries and covariances, and verified K=40/80 series, density/CDF agreement, conditional mass and finite gradients at initial/posterior values. All 66 original fit artifacts remain byte-identical. PNGs were visually inspected; PDFs passed text-bound checks.
