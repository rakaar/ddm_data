## Human RT-only TIED: 250 ms delay bound and 0.25–1.5 s trials

**Question:** does allowing a shared delay up to 250 ms improve the reactive model’s RT-distribution fit, with observed choices still ignored?

**Selection:** `Condition == "RT"` and `0.25 <= RT_s <= 1.5`. Pool raw trials across participants and sessions within each group. Retain correct and incorrect responses; observed response side does not enter the objective. SD and sequential CB are excluded.

| Group | Participants | Previous 0.2–1.5 s fit | New 0.25–1.5 s fit | Additional removals |
|---|---:|---:|---:|---:|
| Control | 11 | 6,528 | 6,524 | 4 |
| ASD | 8 | 4,703 | 4,703 | 0 |

The user approved the 250 ms cap after reviewing the current parameter means and the selection issue. Four additional Control responses (Participant 36, source rows 6418/6492/6987/6992; 226–243 ms) are excluded so that the full delay range is available. Relative to all 11,400 RT trials, 8 responses below 250 ms and 165 above 1.5 s are excluded. The fastest retained responses are 257.898 ms Control and 277.840 ms ASD. Recorded RTs are not shifted or imputed.

**Two changes from the previous RT-only fit:** the delay prior rises from 0–200 to 0–250 ms, and the retained lower RT increases from 200 to 250 ms. Comparisons below evaluate both saved parameter sets on the same new rows and with the same **0.25–1.5 s conditional normalization**.

### Model and RT-only objective

Keep exactly five free parameters shared across both ASLs and all ten signed differences within each group: `rate_lambda`, `T_0`, `theta_E`, `w`, `t_E_aff`. Use the unchanged vanilla/IPL TIED first-passage primitives. `B = Mean_dB` (≈10.892/15.089 visual dB), `D = Delta_dB` (right minus left); retain ASL 20/40 cd/m² as plot labels.

```text
gamma = theta_E * tanh(rate_lambda * D / 17.37)
omega = 10**(rate_lambda * B / 20) * cosh(rate_lambda * D / 17.37) / (T_0 * theta_E**2)
Z_E = (w - 0.5) * 2 * theta_E
first-passage time = RT_s - t_E_aff
p(RT | B,D,retained) = [rho_right(RT) + rho_left(RT)] / Z(B,D)
Z(B,D) = F_right(1.5) + F_left(1.5) - F_right(0.25) - F_left(0.25)
```

This is a trial-level RT likelihood conditional on the stimulus and retained window. Summing both response densities ignores observed choice; the objective does not fit histogram heights or psychometric probabilities.

| Parameter | Prior | Hard support |
|---|---|---|
| `rate_lambda` | LogNormal(log(0.2), 1.5) | >0; no finite upper bound |
| `T_0` (s) | LogNormal(log(0.001), 2) | >0; no finite upper bound |
| `theta_E` | LogNormal(log(30), 1.5) | >0; no finite upper bound |
| `w` | Uniform(0.05, 0.95) | 0.05–0.95 |
| `t_E_aff` (s) | Uniform(0, 0.250) | 0–250 ms |

LogNormal arguments use natural logarithms. All priors except the delay cap are unchanged.

### RTDs and CDFs

![250-ms versus 200-ms RT-only fits on common trials](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/human_RT_only_rtd_cdf_comparison_full_0p25_1p5s.png)

*Control above ASD; pooled RTD left and CDF right. Blue/orange denote ASL 20/40 cd/m². Solid curves use the new 250-ms-cap fit’s arithmetic physical posterior means; dotted curves use the previous 200-ms-cap RT-only means, recomputed with the new retention window. Thin steps show data. Signed conditions are mixed with their actual retained trial frequencies. Histograms use 20 ms bins with a final 10 ms bin from 1.49 to 1.5 s. Choices are not fitted.*

[Full-size PNG](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/human_RT_only_rtd_cdf_comparison_full_0p25_1p5s.png) · [PDF](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/human_RT_only_rtd_cdf_comparison_full_0p25_1p5s.pdf) · [0.25–1 s zoom](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/human_RT_only_rtd_cdf_comparison_zoom_0p25_1s.png)

| Group | Common RT metric | Previous 200 ms cap | New 250 ms cap | Change |
|---|---|---:|---:|---:|
| Control | RT log likelihood (higher better) | 1761.51 | 2045.85 | +284.337 |
| Control | Mean signed-condition CDF gap | 0.260303 | 0.215502 | -0.0448012 |
| Control | Largest signed-condition CDF gap | 0.356754 | 0.307624 | -0.0491303 |
| ASD | RT log likelihood (higher better) | 742.836 | 945.342 | +202.506 |
| ASD | Mean signed-condition CDF gap | 0.237761 | 0.202302 | -0.0354588 |
| ASD | Largest signed-condition CDF gap | 0.330071 | 0.294057 | -0.0360141 |

The mean CDF gap weights each of the 20 ASL × signed-difference cells equally. The likelihood weights individual trials equally; pooled curves use actual trial frequencies. All model curves and scores use arithmetic means of the five physical parameters, rather than averaging predictions over the posterior.

**Visual assessment:** The 250-ms-cap curves improve common-window likelihoods and condition-wise CDF gaps in both groups, but their peaks remain too low and tails too heavy. Control passes the specified window/local-stability checks. ASD reaches the 1,000,000-step cap and remains provisional; its delay posterior is concentrated close to 250 ms.

### RTDs by absolute difference

![250-ms RT-only fit by absolute difference](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/human_RT_only_rtd_by_delta_full_0p25_1p5s.png)

*Control above ASD; columns |ΔdB| = 0.1, 0.3, 0.65, 1.3, 2. Dashed steps are empirical RTDs; solid curves are the 250-ms-cap model at the physical posterior means on a 1 ms grid. Blue/orange identify ASL 20/40 cd/m². Pool ±ΔdB using actual retained counts. The zoom retains the full 0.25–1.5 s normalization. Matching axes include all peaks.*

[Full-size PNG](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/human_RT_only_rtd_by_delta_full_0p25_1p5s.png) · [PDF](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/human_RT_only_rtd_by_delta_full_0p25_1p5s.pdf) · [0.25–1 s zoom](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/human_RT_only_rtd_by_delta_zoom_0p25_1s.png)

### Posterior parameters and delay boundary

| Group | Parameter | Mean | SD | Central 95% interval |
|---|---|---:|---:|---|
| Control | rate_lambda | 0.125268 | 0.0208 | [0.089349, 0.16993] |
| Control | T_0 (ms) | 0.0234064 | 0.0084722 | [0.010975, 0.043694] |
| Control | theta_E | 204.283 | 33.769 | [146.64, 279.25] |
| Control | w | 0.495921 | 0.0089388 | [0.47814, 0.51371] |
| Control | t_E_aff (ms) | 245.387 | 1.9736 | [240.53, 248.12] |
| ASD | rate_lambda | 0.212773 | 0.046006 | [0.13659, 0.31427] |
| ASD | T_0 (ms) | 0.0873242 | 0.045342 | [0.029479, 0.2014] |
| ASD | theta_E | 134.13 | 29.073 | [86.366, 200.6] |
| ASD | w | 0.503766 | 0.0067343 | [0.49038, 0.51722] |
| ASD | t_E_aff (ms) | 249.461 | 0.89285 | [247.28, 249.97] |

| Group | Delay draws >249 ms | Delay draws >245 ms |
|---|---:|---:|
| Control | 0.01% | 65.57% |
| ASD | 86.85% | 99.28% |

These are **variational approximations**, using 10,000 constrained draws per group. Uncertainty from pooled trials does not represent participant-to-participant variability. A delay posterior near 250 ms remains sensitive to the imposed cap.

| Group | Parameter pair | Posterior correlation |
|---|---|---:|
| Control | T_0, rate_lambda | +0.9629 |
| Control | theta_E, T_0 | -0.9215 |
| Control | theta_E, rate_lambda | -0.9061 |
| ASD | T_0, rate_lambda | +0.9572 |
| ASD | theta_E, rate_lambda | -0.8990 |
| ASD | theta_E, T_0 | -0.8710 |

### Optimization and confirmation

One warm start per group transfers the saved 200-ms RT-only full-rank guide, mapping the delay’s latent center and local covariance to 0–250 ms while preserving its physical center. Reset Adam, RNG (seed 0), losses and patience. CPU float64; AutoMultivariateNormal; full batches; one ELBO particle; ClippedAdam rate 0.0002, clip 1. Minimum 50,000 and maximum 1,000,000 new updates.

Every lower 1,000-step mean loss resets patience. Require at least 25 later windows and both terminal and selected-checkpoint local mean stability (<0.1 posterior SD over three checkpoints). Restore the selected checkpoint. These checks do not establish global optimality or unique parameter estimates.

| Group | Selected best step | Final checked step | Later windows | Status |
|---|---:|---:|---:|---|
| Control | 27,000 | 53,000 | 26 | Window and local-stability checks passed |
| ASD | 40,000 | 1,000,000 | 960 | **flagged / unconfirmed** |

**ASD remains provisional after 1,000,000 updates.**
Selected checkpoint at step 40,000: the largest three-checkpoint mean change was 0.1156 posterior SD in `w`, above the 0.1 criterion. The number of post-minimum windows and this parameter-stability test are separate requirements.
Terminal checkpoint at step 1,000,000: the largest three-checkpoint mean change was 0.1298 posterior SD in `w`, above the 0.1 criterion. The number of post-minimum windows and this parameter-stability test are separate requirements.

[Control corner](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/control/parameter_corner.png) · [ASD corner](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/asd/parameter_corner.png) · [Control convergence](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/control/convergence.png) · [ASD convergence](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/asd/convergence.png)

### Sources and independent verification

Fit root: `ASD_Human_Data/reactive_tied_rt_only_svi_0p25_1p5s_delay250ms/`. Previous RT-only fit: `ASD_Human_Data/reactive_tied_rt_only_svi_0p2_1p5s_delay200ms/`.

[Protocol](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/analysis_protocol.json) · [Configuration](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/run_config.json) · [Selection counts](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/selection_counts.csv) · [Excluded rows](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/excluded_trials.csv) · [Participant counts](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/participant_selection_counts.csv) · [Condition counts](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/condition_selection_counts.csv) · [Common-window metrics](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/common_RT_fit_quality.csv) · [Posterior summaries](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/parameter_summary.csv) · [Delay-boundary diagnostics](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/delay_boundary_diagnostics.csv) · [Independent validation](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/independent_validation.json) · [Full posterior/source/audit ZIP](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/human_RT_only_delay250ms_audits.zip)

- `ASD_Human_Data/human_reactive_tied_rt_only_utils.py` ([source](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/source/human_reactive_tied_rt_only_utils.py)).
- `ASD_Human_Data/fit_human_reactive_tied_rt_only_svi.py` ([source](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/source/fit_human_reactive_tied_rt_only_svi.py)).
- `ASD_Human_Data/plot_human_reactive_tied_rt_only_delay250_svi.py` ([source](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/source/plot_human_reactive_tied_rt_only_delay250_svi.py)).
- `ASD_Human_Data/verify_human_reactive_tied_rt_only_delay250_svi.py` ([source](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/source/verify_human_reactive_tied_rt_only_delay250_svi.py)).
- `ASD_Human_Data/publish_human_reactive_tied_rt_only_delay250_svi.py` ([source](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/source/publish_human_reactive_tied_rt_only_delay250_svi.py)).
- `ASD_Human_Data/human_tied_independent_fpt.py` ([source](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/source/human_tied_independent_fpt.py)).
- `ASD_Human_Data/human_reactive_tied_svi_utils.py` ([source](../assets/results/2026-10-20/human_tied_RT_only_delay250ms/source/human_reactive_tied_svi_utils.py)).

Independent checks verified all 11,227 retained and 173 excluded source identities, the newly removed four Control rows, choice-label invariance, exactly five free parameters, the 250 ms support, posterior summaries/covariances, warm-start mapping, strict patience resets, finite gradients, K=40/80 convergence, independent SciPy PDF/CDF agreement, and unit conditional mass. Reconstructed 80 condition CDF comparisons, 1512 histogram bins and 160 mixture weights. Earlier fit/figure files were hash checked, prior documentation preserved, PNGs visually inspected, and PDF text bounds checked.
