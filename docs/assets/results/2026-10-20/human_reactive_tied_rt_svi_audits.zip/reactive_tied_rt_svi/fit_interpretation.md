**Run status:** ASD met the stated loss-patience and parameter-mean stability checks at **127,000 steps**. Control reached the **150,000-step cap** with continued parameter-mean movement and is **flagged unstable**. Both returned their best finite loss-window checkpoint.

At these saved posterior means, the reactive-only model produces broad RTDs whose peaks are earlier than the data. The largest signed-condition RT CDF gaps are **0.471 Control** and **0.347 ASD**. These fits do not reproduce the observed RTD shapes well; Control's instability limits conclusions about its best achievable fit.

| Group | Completed steps | Restored best step | Last-three-checkpoint max mean change (SD) | Mean stability |
|---|---:|---:|---:|---|
| Control | 150,000 | 150,000 | 0.144 | **FAILED** |
| ASD | 127,000 | 127,000 | 0.097 | passed |

| Group | Parameter | Mean | SD | 2.5% | 97.5% |
|---|---|---:|---:|---:|---:|
| Control | rate_lambda | 0.24815 | 0.012752 | 0.22403 | 0.27365 |
| Control | T_0 (ms) | 0.15505 | 0.017822 | 0.12227 | 0.19273 |
| Control | theta_E | 98.686 | 5.3842 | 88.547 | 109.88 |
| Control | w | 0.48743 | 0.0045605 | 0.47835 | 0.49645 |
| Control | t_E_aff (ms) | 104.48 | 0.79919 | 102.76 | 105.92 |
| ASD | rate_lambda | 0.31991 | 0.017036 | 0.28773 | 0.35402 |
| ASD | T_0 (ms) | 0.30872 | 0.037958 | 0.23964 | 0.38924 |
| ASD | theta_E | 71.211 | 4.0635 | 63.587 | 79.7 |
| ASD | w | 0.50721 | 0.0054368 | 0.49632 | 0.518 |
| ASD | t_E_aff (ms) | 173.45 | 1.0893 | 171.09 | 175.37 |

*Time parameters are displayed in ms here; the raw CSV stores seconds. Control summaries are flagged unstable.*

| Group | Joint log likelihood at means | Psychometric RMSE | Max probability error | Mean RT CDF gap | Max RT CDF gap |
|---|---:|---:|---:|---:|---:|
| Control | -2696.285 | 0.0320 | 0.0643 | 0.3173 | 0.4705 |
| ASD | -2145.434 | 0.0537 | 0.1202 | 0.2467 | 0.3469 |

Strong physical-parameter correlations: Control: `theta_E`/`T_0` r = -0.908, `T_0`/`rate_lambda` r = 0.845; ASD: `theta_E`/`T_0` r = -0.888, `T_0`/`rate_lambda` r = 0.826.
